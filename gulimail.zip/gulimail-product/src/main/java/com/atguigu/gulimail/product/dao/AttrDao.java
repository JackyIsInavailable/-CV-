package com.atguigu.gulimail.product.dao;

import com.atguigu.gulimail.product.entity.AttrEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品属性
 * 
 * @author sx
 * @email 1065402636@qq.com
 * @date 2022-10-28 23:51:27
 */
@Mapper
public interface AttrDao extends BaseMapper<AttrEntity> {
	
}
