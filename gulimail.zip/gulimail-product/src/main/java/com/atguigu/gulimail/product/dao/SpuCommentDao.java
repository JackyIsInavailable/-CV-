package com.atguigu.gulimail.product.dao;

import com.atguigu.gulimail.product.entity.SpuCommentEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 商品评价
 * 
 * @author sx
 * @email 1065402636@qq.com
 * @date 2022-10-28 23:51:26
 */
@Mapper
public interface SpuCommentDao extends BaseMapper<SpuCommentEntity> {
	
}
