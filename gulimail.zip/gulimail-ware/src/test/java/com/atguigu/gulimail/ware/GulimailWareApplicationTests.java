package com.atguigu.gulimail.ware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimailWareApplicationTests {

    @Test
    void contextLoads() {
    }

}
