package com.atguigu.gulimail.coupon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimailCouponApplicationTests {

    @Test
    void contextLoads() {
    }

}
