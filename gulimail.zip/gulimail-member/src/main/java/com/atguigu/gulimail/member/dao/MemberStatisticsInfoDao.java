package com.atguigu.gulimail.member.dao;

import com.atguigu.gulimail.member.entity.MemberStatisticsInfoEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 会员统计信息
 * 
 * @author sx
 * @email 1065402636@qq.com
 * @date 2022-10-29 13:05:33
 */
@Mapper
public interface MemberStatisticsInfoDao extends BaseMapper<MemberStatisticsInfoEntity> {
	
}
