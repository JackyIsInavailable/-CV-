package com.atguigu.gulimail.member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimailMemberApplicationTests {

    @Test
    void contextLoads() {
    }

}
