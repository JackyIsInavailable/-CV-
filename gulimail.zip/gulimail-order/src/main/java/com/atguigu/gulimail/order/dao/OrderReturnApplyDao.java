package com.atguigu.gulimail.order.dao;

import com.atguigu.gulimail.order.entity.OrderReturnApplyEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单退货申请
 * 
 * @author sx
 * @email 1065402636@qq.com
 * @date 2022-10-29 13:16:06
 */
@Mapper
public interface OrderReturnApplyDao extends BaseMapper<OrderReturnApplyEntity> {
	
}
